package scholarship.management.system;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StudentDetails extends JFrame {
    private JTable table;

    public StudentDetails() {
        setTitle("Student Details Page");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("USN");
        model.addColumn("Scholarship ID");
        model.addColumn("Semester");
        model.addColumn("Apply Date");
        model.addColumn("Status");

        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Apply";
            ResultSet rs = c.s.executeQuery(query);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("USN"),
                        rs.getInt("S_ID"),
                        rs.getInt("SEM"),
                        rs.getDate("ApplyDate"),
                        rs.getString("Status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the database");
        } finally {
            c.close();
        }

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane);

        JButton backButton = new JButton("Back");
         backButton.setBackground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                new Faculty(); 
            }
        });
        getContentPane().add(backButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new StudentDetails();
    }
}
