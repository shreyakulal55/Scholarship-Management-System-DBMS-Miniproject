/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;

public class UpdateScholarship extends JFrame implements ActionListener {

    JTextField tfScholarshipId, tfScholarshipName, tfStartDate, tfDeadline, tfAmount, tfApplyLink;
    JComboBox<String> agencyDropdown, facultyDropdown;
    JButton btnUpdate, btnCancel;

    public UpdateScholarship() {
        setLayout(null);
  getContentPane().setBackground(Color.GRAY);
        JLabel lblScholarshipId = new JLabel("Scholarship ID:");
        lblScholarshipId.setBounds(40, 20, 150, 30);
        add(lblScholarshipId);
        tfScholarshipId = new JTextField();
        tfScholarshipId.setBounds(200, 20, 150, 30);
        add(tfScholarshipId);

        JLabel lblScholarshipName = new JLabel("Scholarship Name:");
        lblScholarshipName.setBounds(40, 70, 150, 30);
        add(lblScholarshipName);
        tfScholarshipName = new JTextField();
        tfScholarshipName.setBounds(200, 70, 150, 30);
        add(tfScholarshipName);

        JLabel lblStartDate = new JLabel("Start Date (YYYY-MM-DD):");
        lblStartDate.setBounds(40, 120, 150, 30);
        add(lblStartDate);
        tfStartDate = new JTextField();
        tfStartDate.setBounds(200, 120, 150, 30);
        add(tfStartDate);

        JLabel lblDeadline = new JLabel("Deadline (YYYY-MM-DD):");
        lblDeadline.setBounds(40, 170, 150, 30);
        add(lblDeadline);
        tfDeadline = new JTextField();
        tfDeadline.setBounds(200, 170, 150, 30);
        add(tfDeadline);

        JLabel lblAmount = new JLabel("Amount:");
        lblAmount.setBounds(40, 220, 150, 30);
        add(lblAmount);
        tfAmount = new JTextField();
        tfAmount.setBounds(200, 220, 150, 30);
        add(tfAmount);

        JLabel lblAgency = new JLabel("Agency:");
        lblAgency.setBounds(40, 270, 150, 30);
        add(lblAgency);

        String[] agencyOptions = getAgencyOptions();
        agencyDropdown = new JComboBox<>(agencyOptions);
        agencyDropdown.setBounds(200, 270, 150, 30);
        add(agencyDropdown);

        JLabel lblApplyLink = new JLabel("Apply Link:");
        lblApplyLink.setBounds(40, 320, 150, 30);
        add(lblApplyLink);
        tfApplyLink = new JTextField();
        tfApplyLink.setBounds(200, 320, 150, 30);
        add(tfApplyLink);

        JLabel lblFaculty = new JLabel("Faculty:");
        lblFaculty.setBounds(40, 370, 150, 30);
        add(lblFaculty);

        String[] facultyOptions = getFacultyOptions();
        facultyDropdown = new JComboBox<>(facultyOptions);
        facultyDropdown.setBounds(200, 370, 150, 30);
        add(facultyDropdown);

        btnUpdate = new JButton("Update Scholarship");
        btnUpdate.setBounds(200, 420, 150, 30);
            btnUpdate.setBackground(Color.WHITE);
        btnUpdate.addActionListener(this);
        add(btnUpdate);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(360, 420, 100, 30);
            btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        add(btnCancel);

        setTitle("Update Scholarship");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private String[] getFacultyOptions() {
        Conn c = new Conn();
        try {
            String query = "SELECT F_Id FROM Faculty";
            ResultSet rs = c.s.executeQuery(query);

            java.util.List<String> facultyOptionsList = new ArrayList<>();
            while (rs.next()) {
                facultyOptionsList.add(rs.getString("F_Id"));
            }
            String[] facultyOptions = facultyOptionsList.toArray(new String[0]);

            return facultyOptions;
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[0];
        } finally {
            c.close();
        }
    }

    private String[] getAgencyOptions() {
        Conn c = new Conn();
        try {
            String query = "SELECT AID, Provider FROM Agency";
            ResultSet rs = c.s.executeQuery(query);
            java.util.List<String> agencyList = new java.util.ArrayList<>();

            while (rs.next()) {
                int aid = rs.getInt("AID");
                String provider = rs.getString("Provider");
                agencyList.add(aid + " - " + provider);
            }
            return agencyList.toArray(new String[0]);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching agency options");
            return new String[0];
        } finally {
            c.close();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnUpdate) {
            updateScholarship();
        } else if (ae.getSource() == btnCancel) {
            dispose();
        }
    }

    private void updateScholarship() {
        Conn c = new Conn();
        try {
            String scholarshipId = tfScholarshipId.getText();
            String scholarshipName = tfScholarshipName.getText();
            String startDate = tfStartDate.getText();
            String deadline = tfDeadline.getText();
            double amount = Double.parseDouble(tfAmount.getText());
            String applyLink = tfApplyLink.getText();
            String selectedAgencyOption = (String) agencyDropdown.getSelectedItem();
            String[] agencyParts = selectedAgencyOption.split(" - ");
            int aid = Integer.parseInt(agencyParts[0]);
            String provider = agencyParts[1];
            String selectedFaculty = (String) facultyDropdown.getSelectedItem();
            if (!validateAgency(aid, provider)) {
                JOptionPane.showMessageDialog(this, "AID and Provider do not match. Please select a valid combination.");
                return;
            }
            if (!checkScholarshipExistence(scholarshipId)) {
                JOptionPane.showMessageDialog(this, "Scholarship ID does not exist. Please enter a valid ID.");
                return;
            }
            String updateQuery = "UPDATE Scholarships SET ScholarshipName = '" + scholarshipName + "', " +
                    "Start_Date = '" + startDate + "', Deadline = '" + deadline + "', Amount = " + amount + ", " +
                    "AID = " + aid + ", ApplyLink = '" + applyLink + "', F_Id = '" + selectedFaculty + "' " +
                    "WHERE S_ID = '" + scholarshipId + "'";
            c.s.executeUpdate(updateQuery);

            JOptionPane.showMessageDialog(this, "Scholarship updated successfully");
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating scholarship");
        } finally {
            c.close();
        }
    }

    private boolean validateAgency(int aid, String provider) {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Agency WHERE AID = " + aid + " AND Provider = '" + provider + "'";
            ResultSet rs = c.s.executeQuery(query);
            return rs.next();  
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            c.close();
        }
    }

    private boolean checkScholarshipExistence(String scholarshipId) {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Scholarships WHERE S_ID = '" + scholarshipId + "'";
            ResultSet rs = c.s.executeQuery(query);
            return rs.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            c.close();
        }
    }

    private void clearFields() {
        tfScholarshipId.setText("");
        tfScholarshipName.setText("");
        tfStartDate.setText("");
        tfDeadline.setText("");
        tfAmount.setText("");
        tfApplyLink.setText("");
        agencyDropdown.setSelectedIndex(0);
        facultyDropdown.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        new UpdateScholarship();
    }
}
