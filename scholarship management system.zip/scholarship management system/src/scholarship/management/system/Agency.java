/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Agency extends JFrame implements ActionListener {

    JButton btnAddAgency, btnDeleteAgency, btnReadAllAgencies, btnUpdateAgency, btnBack;

    public Agency() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        getContentPane().setBackground(Color.GRAY);
        btnAddAgency = createButton("Add New Agency", 300, 70);
        btnDeleteAgency = createButton("Delete Existing Agency", 300, 70);
        btnUpdateAgency = createButton("Update Existing Agency", 300, 70);
        btnReadAllAgencies = createButton("Read All Agencies", 300, 70);
        btnBack = createSmallButton("Back");

        add(btnAddAgency, gbc);
        gbc.gridy++;
        add(btnDeleteAgency, gbc);
        gbc.gridy++;
        add(btnUpdateAgency, gbc);
        gbc.gridy++;
        add(btnReadAllAgencies, gbc);

        gbc.gridy++;
        gbc.anchor = GridBagConstraints.LAST_LINE_END;
        add(btnBack, gbc);

        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private JButton createButton(String label, int width, int height) {
        JButton button = new JButton(label);
        button.addActionListener(this);
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(width, height));
        return button;
    }

    private JButton createSmallButton(String label) {
        JButton button = new JButton(label);
        button.addActionListener(this);
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(100, 40));
        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnAddAgency) {
            new AddAgency(this);
        } else if (ae.getSource() == btnDeleteAgency) {
            new DeleteAgency();
        } else if (ae.getSource() == btnUpdateAgency) {
            new UpdateAgency();
        } else if (ae.getSource() == btnReadAllAgencies) {
            readAllAgencies();
        } else if (ae.getSource() == btnBack) {
            dispose();
            new Faculty();
        }
    }

    private void readAllAgencies() {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Agency";
            ResultSet rs = c.s.executeQuery(query);

            JTable table = new JTable(buildTableModel(rs));
            JScrollPane scrollPane = new JScrollPane(table);

            JFrame frame = new JFrame("All Agencies");
            frame.setLayout(new BorderLayout());
            frame.add(scrollPane, BorderLayout.CENTER);
            frame.setSize(800, 500);
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JButton backButton = new JButton("Back");
            backButton.setBackground(Color.WHITE);
            backButton.addActionListener(e -> frame.dispose());
            frame.add(backButton, BorderLayout.SOUTH);

            frame.setVisible(true);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error reading agencies from the database");
        } finally {
            c.close();
        }

    }

    private static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        String[] columnNames = new String[metaData.getColumnCount()];
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            columnNames[i - 1] = metaData.getColumnName(i);
        }
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(columnNames);

        while (rs.next()) {
            Object[] rowData = new Object[metaData.getColumnCount()];
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                rowData[i - 1] = rs.getObject(i);
            }
            tableModel.addRow(rowData);
        }
        return tableModel;
    }

    public static void main(String[] args) {
        new Agency();
    }
}
