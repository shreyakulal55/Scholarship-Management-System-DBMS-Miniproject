/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;
/**
 *
 * @author Shreya
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    JTextField tfusername, tfpassword;
    JComboBox<String> roleDropdown;
    public Login() {
        getContentPane().setBackground(Color.gray);
        setLayout(null);
        JLabel headingLabel = new JLabel("SCHOLARSHIP MANAGEMENT SYSTEM");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 30)); 
        headingLabel.setBounds(100, 50, 600, 30);
        headingLabel.setForeground(Color.WHITE);
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER); 
        add(headingLabel);
        JLabel lblusername = new JLabel("Username:");
        lblusername.setBounds(260, 140, 100, 30);
        lblusername.setFont(new Font("Arial", Font.PLAIN, 20));
        lblusername.setForeground(Color.WHITE);
        add(lblusername);

        tfusername = new JTextField();
        tfusername.setBounds(380, 140, 150, 30); 
        add(tfusername);

        JLabel lblpassword = new JLabel("Password:");
        lblpassword.setBounds(260, 200, 100, 30);
        lblpassword.setFont(new Font("Arial", Font.PLAIN, 20));
        lblpassword.setForeground(Color.WHITE);
        add(lblpassword);

        tfpassword = new JPasswordField(); 
        tfpassword.setBounds(380, 200, 150, 30);
        add(tfpassword);

        JLabel lblrole = new JLabel("Role:");
        lblrole.setBounds(260, 260, 100, 30); 
        lblrole.setFont(new Font("Arial", Font.PLAIN, 20));
        lblrole.setForeground(Color.WHITE);
        add(lblrole);

        String[] roles = {"Faculty", "Student"};
        roleDropdown = new JComboBox<>(roles);
        roleDropdown.setBounds(380, 260, 150, 30);
        add(roleDropdown);

        JButton login = new JButton("LOGIN");
        login.setBounds(340, 320, 100, 30); 
        login.setBackground(Color.WHITE);
        login.setForeground(Color.BLACK);
        login.addActionListener(this);
        add(login);

        setSize(800, 500);
        setLocation(450, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String username = tfusername.getText();
            String password = tfpassword.getText();
            String role = (String) roleDropdown.getSelectedItem();
            Conn c = new Conn();
            String query = "";

            if (role.equals("Faculty")) {
                query = "select * from Faculty where FacultyName = '" + username + "' and F_id = '" + password + "'";
            } else if (role.equals("Student")) {
                query = "select * from Student where StudentName = '" + username + "' and USN = '" + password + "'";
            }

            ResultSet rs = c.s.executeQuery(query);

            if (rs.next()) {
                setVisible(false);
                if (role.equals("Faculty")) {
                    new Faculty();
                } else if (role.equals("Student")) {
                    new Student();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username, password, or role");       
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
