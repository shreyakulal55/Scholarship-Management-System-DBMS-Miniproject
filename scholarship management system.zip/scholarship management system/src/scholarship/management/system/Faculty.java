/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Faculty extends JFrame implements ActionListener {

    JButton btnAgency, btnScholarship, btnStudentDetails, btnLogout;

    public Faculty() {
        JLabel headingLabel = new JLabel("FACULTY DASHBOARD");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 30)); 
        headingLabel.setBounds(100, 50, 600, 30);
        headingLabel.setForeground(Color.WHITE);
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER); 
        add(headingLabel);
        
        getContentPane().setBackground(Color.GRAY);
        setLayout(null);
        btnLogout = new JButton("Logout");
        btnLogout.setBounds(330, 380, 100, 30);
        btnLogout.addActionListener(this);
        btnLogout.setBackground(Color.WHITE);
        add(btnLogout);

        btnAgency = new JButton("Agency");
          btnAgency.setBounds(280, 140, 200, 50);
        btnAgency.addActionListener(this);
        btnAgency.setBackground(Color.WHITE);
        add(btnAgency);

        btnScholarship = new JButton("Scholarship");
        btnScholarship.setBounds(280, 220, 200, 50);
        btnScholarship.addActionListener(this);
        btnScholarship.setBackground(Color.WHITE);
        add(btnScholarship);

        btnStudentDetails = new JButton("Student Details");
         btnStudentDetails.setBounds(280, 300, 200, 50); 
        btnStudentDetails.addActionListener(this);
        btnStudentDetails.setBackground(Color.WHITE);
        add(btnStudentDetails);
        setSize(800, 500);

        setLocation(450, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnAgency) {
            new Agency();
        } else if (ae.getSource() == btnScholarship) {
            new Scholarship();
        } else if (ae.getSource() == btnStudentDetails) {
            new StudentDetails();
        } else if (ae.getSource() == btnLogout) {
            dispose();
            new Login();
        }
    }

    public static void main(String[] args) {
        new Faculty();
    }
}
