/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateAgency extends JFrame implements ActionListener {

    JTextField txtAgencyID, txtProvider;
    JButton btnUpdate, btnCancel;

    public UpdateAgency() {
        setTitle("Update Agency");
        setSize(500, 200);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.GRAY);
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
          panel.setBackground(Color.GRAY);

        JLabel lblAgencyID = new JLabel("Agency ID:");
        panel.add(lblAgencyID);

        txtAgencyID = new JTextField();
        panel.add(txtAgencyID);

        JLabel lblProvider = new JLabel("New Provider:");
        panel.add(lblProvider);

        txtProvider = new JTextField();
        panel.add(txtProvider);

        btnUpdate = new JButton("Update");
        btnUpdate.setBackground(Color.WHITE);
        btnUpdate.addActionListener(this);
        panel.add(btnUpdate);

        btnCancel = new JButton("Cancel");
        btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        panel.add(btnCancel);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnUpdate) {
            updateAgency();
        } else if (ae.getSource() == btnCancel) {
            dispose();
        }
    }

    private void updateAgency() {
        try {
            int agencyID = Integer.parseInt(txtAgencyID.getText());
            String newProvider = txtProvider.getText();

            Conn c = new Conn();

            String updateQuery = "UPDATE agency SET Provider = ? WHERE AID = ?";
            PreparedStatement pstmt = c.c.prepareStatement(updateQuery);
            pstmt.setString(1, newProvider);
            pstmt.setInt(2, agencyID);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Agency updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update agency. Please check the Agency ID.");
            }

            c.close();
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating agency. Please check the input.");
        }
    }

    public static void main(String[] args) {
        new UpdateAgency();
    }
}
