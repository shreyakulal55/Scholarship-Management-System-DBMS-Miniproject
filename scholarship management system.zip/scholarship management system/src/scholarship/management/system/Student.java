/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Student extends JFrame implements ActionListener {

    JTextField tfSearch;
    JButton btnSearch, btnUpdateStatus, btnLogout;
    JTable scholarshipsTable;

    public Student() {
        setLayout(new BorderLayout());
        JPanel searchPanel = new JPanel();
        tfSearch = new JTextField(20);
        btnSearch = new JButton("Search");
        btnSearch.setBackground(Color.WHITE);
        btnSearch.addActionListener(this);

        searchPanel.add(new JLabel("Search by Scholarship Name:"));
        searchPanel.add(tfSearch);
        searchPanel.add(btnSearch);
        add(searchPanel, BorderLayout.NORTH);

        scholarshipsTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(scholarshipsTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        btnUpdateStatus = new JButton("Update Status");
        btnUpdateStatus.setBackground(Color.WHITE);
        btnUpdateStatus.addActionListener(this);
        buttonPanel.add(btnUpdateStatus);
        add(buttonPanel, BorderLayout.SOUTH);

        btnLogout = new JButton("Logout");
        btnLogout.setBackground(Color.WHITE);
        btnLogout.addActionListener(this);
        buttonPanel.add(btnLogout);

        add(buttonPanel, BorderLayout.SOUTH);

        setTitle("View All Scholarships");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);

        loadAllScholarships();
    }

    private void loadAllScholarships() {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Scholarships";
            ResultSet rs = c.s.executeQuery(query);
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Scholarship ID");
            model.addColumn("Scholarship Name");
            model.addColumn("Start Date");
            model.addColumn("Deadline");
            model.addColumn("Amount");
            model.addColumn("Apply Link");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("S_Id"),
                    rs.getString("ScholarshipName"),
                    rs.getString("Start_Date"),
                    rs.getString("Deadline"),
                    rs.getDouble("Amount"),
                    rs.getString("ApplyLink")
                });
            }

            scholarshipsTable.setModel(model);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            c.close();
        }
    }

    private void searchScholarships(String scholarshipName) {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Scholarships WHERE ScholarshipName LIKE '%" + scholarshipName + "%'";
            ResultSet rs = c.s.executeQuery(query);
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Scholarship ID");
            model.addColumn("Scholarship Name");
            model.addColumn("Start Date");
            model.addColumn("Deadline");
            model.addColumn("Amount");
            model.addColumn("Apply Link");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("S_Id"),
                    rs.getString("ScholarshipName"),
                    rs.getString("Start_Date"),
                    rs.getString("Deadline"),
                    rs.getDouble("Amount"),
                    rs.getString("ApplyLink")
                });
            }

            scholarshipsTable.setModel(model);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            c.close();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnSearch) {
            String scholarshipName = tfSearch.getText();
            searchScholarships(scholarshipName);
        } else if (ae.getSource() == btnUpdateStatus) {
            new ApplyStatus();
        } else if (ae.getSource() == btnLogout) {
            dispose();
            new Login();
        }
    }

    public static void main(String[] args) {
        new Student();
    }
}
