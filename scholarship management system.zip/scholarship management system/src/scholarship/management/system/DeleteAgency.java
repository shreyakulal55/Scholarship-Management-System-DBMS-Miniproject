/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class DeleteAgency extends JFrame implements ActionListener {

    JTextField tfAgencyId;
    JButton btnDelete, btnCancel;

    public DeleteAgency() {
        setLayout(null);
  getContentPane().setBackground(Color.GRAY);
        JLabel lblAgencyId = new JLabel("Agency ID:");
        lblAgencyId.setBounds(40, 20, 150, 30);
        add(lblAgencyId);
        
        tfAgencyId = new JTextField();
        tfAgencyId.setBounds(200, 20, 150, 30);
        add(tfAgencyId);

        btnDelete = new JButton("Delete Agency");
        btnDelete.setBounds(200, 70, 150, 30);
           btnDelete.setBackground(Color.WHITE);
        btnDelete.addActionListener(this);
        add(btnDelete);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(360, 70, 100, 30);
           btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        add(btnCancel);

        setTitle("Delete Agency");
        setSize(500, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnDelete) {
            deleteAgency();
        } else if (ae.getSource() == btnCancel) {
            dispose();
        }
    }

    private void deleteAgency() {
        Conn c = new Conn();
        try {
            String agencyId = tfAgencyId.getText();

            if (agencyId.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an Agency ID");
                return;
            }

            if (!agencyExists(agencyId)) {
                JOptionPane.showMessageDialog(this, "Agency with ID " + agencyId + " does not exist");
                return;
            }

            String deleteQuery = "DELETE FROM Agency WHERE AID = " + agencyId;
            c.s.executeUpdate(deleteQuery);

            JOptionPane.showMessageDialog(this, "Agency deleted successfully");
            dispose();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting agency");
        } finally {
            c.close();
        }
    }

    private boolean agencyExists(String agencyId) throws SQLException {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Agency WHERE AID = " + agencyId;
            ResultSet rs = c.s.executeQuery(query);
            return rs.next();
        } finally {
            c.close();
        }
    }

    public static void main(String[] args) {
        new DeleteAgency();
    }
}
