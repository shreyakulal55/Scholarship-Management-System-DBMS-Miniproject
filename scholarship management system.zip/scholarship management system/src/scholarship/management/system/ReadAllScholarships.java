/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ReadAllScholarships extends JFrame {

    JTable scholarshipTable;

    
    public ReadAllScholarships() {
        setLayout(new BorderLayout());
        String[] columns = {"Scholarship ID", "Faculty ID", "Scholarship Name", "Start Date", "Deadline", "Amount", "Agency ID", "Apply Link"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        scholarshipTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(scholarshipTable);
        
        add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
         backButton.setBackground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                new Scholarship(); 
            }
        });
        add(backButton, BorderLayout.SOUTH);
        
        setTitle("All Scholarships");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        readScholarships();
    }

    private void readScholarships() {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Scholarships";
            ResultSet rs = c.s.executeQuery(query);
            while (rs.next()) {
                String scholarshipId = rs.getString("S_ID");
                String facultyId = rs.getString("F_Id");
                String scholarshipName = rs.getString("ScholarshipName");
                String startDate = rs.getString("Start_Date");
                String deadline = rs.getString("Deadline");
                double amount = rs.getDouble("Amount");
                int agencyId = rs.getInt("AID");
                String applyLink = rs.getString("ApplyLink");

                Object[] row = {scholarshipId, facultyId, scholarshipName, startDate, deadline, amount, agencyId, applyLink};
                DefaultTableModel model = (DefaultTableModel) scholarshipTable.getModel();
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching scholarships");
        } finally {
            c.close();
        }
    }

    public static void main(String[] args) {
        new ReadAllScholarships();
    }
}
