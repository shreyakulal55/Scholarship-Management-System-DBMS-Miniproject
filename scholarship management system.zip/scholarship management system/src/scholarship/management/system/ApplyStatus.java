package scholarship.management.system;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class ApplyStatus extends JFrame implements ActionListener {
    JTextField tfUSN, tfScholarshipID, tfStatus, tfApplyDate, tfSemester;
    JButton btnUpdate, btnCancel;

    public ApplyStatus() {
        setTitle("Update Scholarship Status");
        setSize(400, 250); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(6, 2));

        panel.add(new JLabel("USN:"));
        tfUSN = new JTextField();
        panel.add(tfUSN);

        panel.add(new JLabel("Scholarship ID:"));
        tfScholarshipID = new JTextField();
        panel.add(tfScholarshipID);

        panel.add(new JLabel("Status:"));
        tfStatus = new JTextField();
        panel.add(tfStatus);

        panel.add(new JLabel("Apply Date:"));
        tfApplyDate = new JTextField();
        panel.add(tfApplyDate);

        panel.add(new JLabel("Semester:"));
        tfSemester = new JTextField();
        panel.add(tfSemester);

        btnUpdate = new JButton("Update Status");
        btnUpdate.addActionListener(this);
            btnUpdate.setBackground(Color.WHITE);
        panel.add(btnUpdate);

        btnCancel = new JButton("Cancel");
            btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        panel.add(btnCancel);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            updateStatus();
        } else if (e.getSource() == btnCancel) {
            dispose();
        }
    }

    private void updateStatus() {
        String usn = tfUSN.getText();
        int scholarshipID = Integer.parseInt(tfScholarshipID.getText());
        String status = tfStatus.getText();
        String applyDate = tfApplyDate.getText();
        int semester = Integer.parseInt(tfSemester.getText());

        try {
            Conn c = new Conn();
            String query = "INSERT INTO Apply (USN, S_ID, ApplyDate, SEM, Status) " +
                           "VALUES (?, ?, ?, ?, ?) " +
                           "ON DUPLICATE KEY UPDATE ApplyDate = ?, SEM = ?, Status = ?";
            PreparedStatement pstmt = c.c.prepareStatement(query);
            pstmt.setString(1, usn);
            pstmt.setInt(2, scholarshipID);
            pstmt.setString(3, applyDate);
            pstmt.setInt(4, semester);
            pstmt.setString(5, status);
            pstmt.setString(6, applyDate);
            pstmt.setInt(7, semester);
            pstmt.setString(8, status);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Status updated successfully");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update status");
            }
            c.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating status");
        }
    }

    public static void main(String[] args) {
        new ApplyStatus();
    }
}
