/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class DeleteScholarship extends JFrame implements ActionListener {

    JTextField tfScholarshipId;
    JButton btnDelete, btnCancel;

    public DeleteScholarship() {
        setLayout(null);
  getContentPane().setBackground(Color.GRAY);
        JLabel lblScholarshipId = new JLabel("Scholarship ID:");
        lblScholarshipId.setBounds(40, 20, 150, 30);
        add(lblScholarshipId);
        
        tfScholarshipId = new JTextField();
        tfScholarshipId.setBounds(200, 20, 150, 30);
        add(tfScholarshipId);

        btnDelete = new JButton("Delete Scholarship");
        btnDelete.setBounds(200, 70, 150, 30);
         btnDelete.setBackground(Color.WHITE);
        btnDelete.addActionListener(this);
        add(btnDelete);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(360, 70, 100, 30);
         btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        add(btnCancel);

        setTitle("Delete Scholarship");
        setSize(500, 150);
        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnDelete) {
            deleteScholarship();
        } else if (ae.getSource() == btnCancel) {
            dispose();
        }
    }

    private void deleteScholarship() {
        Conn c = new Conn();
        try {
            String scholarshipId = tfScholarshipId.getText();

            if (scholarshipId.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a Scholarship ID");
                return;
            }

            if (!scholarshipExists(scholarshipId)) {
                JOptionPane.showMessageDialog(this, "Scholarship with ID " + scholarshipId + " does not exist");
                return;
            }

            String deleteQuery = "DELETE FROM Scholarships WHERE s_id = '" + scholarshipId + "'";
            c.s.executeUpdate(deleteQuery);

            JOptionPane.showMessageDialog(this, "Scholarship deleted successfully");
            dispose();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting scholarship");
        } finally {
            c.close();
        }
    }

    private boolean scholarshipExists(String scholarshipId) throws SQLException {
        Conn c = new Conn();
        try {
            String query = "SELECT * FROM Scholarships WHERE s_id = '" + scholarshipId + "'";
            ResultSet rs = c.s.executeQuery(query);
            return rs.next();
        } finally {
            c.close();
        }
    }

    public static void main(String[] args) {
        new DeleteScholarship();
    }
}
