/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Shreya
 */

package scholarship.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scholarship extends JFrame implements ActionListener {
    JButton btnAddScholarship, btnUpdateScholarship, btnReadAllScholarships, btnDeleteScholarship, btnBack;
    public Scholarship() {
        setLayout(new GridBagLayout()); 
         getContentPane().setBackground(Color.GRAY);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        btnAddScholarship = createButton("Add New Scholarship", 300, 70);
        btnUpdateScholarship = createButton("Update Existing Scholarship", 300, 70);
        btnReadAllScholarships = createButton("Read All Scholarships", 300, 70);
        btnDeleteScholarship = createButton("Delete Scholarship", 300, 70);
        btnBack = createSmallButton("Back");
        add(btnAddScholarship, gbc);
        gbc.gridy++;
        add(btnUpdateScholarship, gbc);
        gbc.gridy++;
        add(btnReadAllScholarships, gbc);
        gbc.gridy++;
        add(btnDeleteScholarship, gbc);
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.LAST_LINE_END;
        add(btnBack, gbc);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private JButton createButton(String label, int width, int height) {
        JButton button = new JButton(label);
        button.addActionListener(this);
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(width, height));
        return button;
    }

    private JButton createSmallButton(String label) {
        JButton button = new JButton(label);
        button.addActionListener(this);
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(100, 40));
        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnAddScholarship) {
            new AddScholarship();  
        } else if (ae.getSource() == btnUpdateScholarship) {
            new UpdateScholarship();  
        } else if (ae.getSource() == btnReadAllScholarships) {
            new ReadAllScholarships();  
        } else if (ae.getSource() == btnDeleteScholarship) {
            new DeleteScholarship();  
        } else if (ae.getSource() == btnBack) {
            dispose();  
            new Faculty(); 
        }
    }

    public static void main(String[] args) {
        new Scholarship();
    }
}


