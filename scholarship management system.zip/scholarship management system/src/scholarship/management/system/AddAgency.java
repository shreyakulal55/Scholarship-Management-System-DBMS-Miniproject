/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scholarship.management.system;

/**
 *
 * @author Shreya
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddAgency extends JFrame implements ActionListener {

    JTextField tfAID, tfProvider;
    JButton btnAdd, btnCancel;

    Agency parentFrame;

    public AddAgency(Agency parentFrame) {
        this.parentFrame = parentFrame;
        getContentPane().setBackground(Color.GRAY);
        setLayout(null);

        JLabel lblAID = new JLabel("Agency ID:");
        lblAID.setBounds(40, 20, 100, 30);
        add(lblAID);
        tfAID = new JTextField();
        tfAID.setBounds(150, 20, 150, 30);
        add(tfAID);

        JLabel lblProvider = new JLabel("Provider:");
        lblProvider.setBounds(40, 100, 100, 30);
        add(lblProvider);
        tfProvider = new JTextField();
        tfProvider.setBounds(150, 100, 150, 30);
        add(tfProvider);

        btnAdd = new JButton("Add Agency");
        btnAdd.setBounds(150, 170, 150, 30);
        btnAdd.setBackground(Color.WHITE);
        btnAdd.addActionListener(this);
        add(btnAdd);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(200, 240, 100, 30);
        btnCancel.setBackground(Color.WHITE);
        btnCancel.addActionListener(this);
        add(btnCancel);

        setTitle("Add New Agency");
        setSize(800, 500);
        setLocationRelativeTo(parentFrame);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnAdd) {
            addAgency();
        } else if (ae.getSource() == btnCancel) {
            dispose();
        }
    }

    private void addAgency() {
        Conn c = new Conn();
        try {
            int aid = Integer.parseInt(tfAID.getText());

            String provider = tfProvider.getText();

            String query = "INSERT INTO Agency VALUES (" + aid + ", '" + provider + "')";
            c.s.executeUpdate(query);

            JOptionPane.showMessageDialog(this, "Agency added successfully");
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding agency");
        } finally {
            c.close();
        }
    }

    private void goBack() {
        dispose();
        parentFrame.setVisible(true);
    }

    private void clearFields() {
        tfAID.setText("");
        tfProvider.setText("");
    }
}
